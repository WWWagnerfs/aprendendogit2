import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: IMCCalculadora(),
    debugShowCheckedModeBanner: false,
  ));
}

class IMCCalculadora extends StatefulWidget {
  @override
  _IMCCalculatorState createState() => _IMCCalculatorState();
}

class _IMCCalculatorState extends State<IMCCalculadora> {
  TextEditingController weightController = TextEditingController();
  TextEditingController heightController = TextEditingController();
  String resultado = '';
  Color resultadoCor = Colors.black;

  Color cor(double imc) {
    if (imc < 18.5) {
      return Colors.green;
    } else if (imc >= 18.5 && imc < 25) {
      return Colors.blue;
    } else if (imc >= 25 && imc < 30) {
      return Colors.orange;
    } else if (imc >= 30 && imc < 35) {
      return Colors.red;
    } else if (imc >= 35 && imc < 40) {
      return Colors.red;
    } else {
      return Colors.red;
    }
  }

  void calculaIMC() {
    final weightInput = weightController.text.replaceAll(',', '.');
    final heightInput = heightController.text.replaceAll(',', '.');

    double weight = double.tryParse(weightInput) ?? 0.0;
    double height = double.tryParse(heightInput) ?? 0.0;

    if (weight > 0 && height > 0) {
      double imc = weight / (height * height);
      Color color = cor(imc);

      setState(() {
        if (imc < 18.5) {
          resultado = 'Abaixo de 18.5 - Baixo Peso (${imc.toStringAsFixed(2)})';
        } else if (imc >= 18.5 && imc < 25) {
          resultado =
              'Entre 18.5 e 24.99 - Peso Normal (${imc.toStringAsFixed(2)})';
        } else if (imc >= 25 && imc < 30) {
          resultado =
              'Entre 25 e 29.99 - Sobrepeso (${imc.toStringAsFixed(2)})';
        } else if (imc >= 30 && imc < 35) {
          resultado =
              'Entre 30 e 34.99 - Obesidade Grau I (${imc.toStringAsFixed(2)})';
        } else if (imc >= 35 && imc < 40) {
          resultado =
              'Entre 35 e 39.99 - Obesidade Grau II (${imc.toStringAsFixed(2)})';
        } else {
          resultado =
              'Acima de 40 - Obesidade Grau III (${imc.toStringAsFixed(2)})';
        }
        resultadoCor = color;
      });
    } else {
      setState(() {
        resultado = 'Informe peso e altura válidos';
        resultadoCor = Colors.black;
      });
    }
  }

  void limpaDados() {
    setState(() {
      weightController.text = '';
      heightController.text = '';
      resultado = '';
      resultadoCor = Color.fromARGB(255, 50, 109, 238);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Align(
          alignment: Alignment.center, // Centraliza o conteúdo
          child: Row(
            mainAxisAlignment:
                MainAxisAlignment.center, // Centraliza o título na row
            children: [
              Icon(Icons.menu),
              SizedBox(width: 15.0),
              Text('Calculadora IMC'),
            ],
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: weightController,
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: 'Peso (KG)'),
            ),
            TextField(
              controller: heightController,
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: 'Altura (Metros)'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: calculaIMC,
              child: Text('Calcular IMC'),
            ),
            SizedBox(height: 16.0),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(12.0),
              decoration: BoxDecoration(
                color: resultadoCor,
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Text(
                'Resultado: $resultado',
                style: TextStyle(fontSize: 18.0, color: Colors.white),
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: limpaDados,
              child: Text('Limpar Dados'),
            ),
          ],
        ),
      ),
    );
  }
}
